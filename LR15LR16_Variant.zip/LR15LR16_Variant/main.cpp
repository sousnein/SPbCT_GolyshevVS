#include <windows.h>
#include <string>
#define ID_BUTTON1 100
using namespace std;
HWND hMain, hStatic1, hStatic2, hStatic3, hStatic4, hEdit1, hEdit2, hEdit3, hEdit4, hButton1;
LRESULT CALLBACK WindowProcedure(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp) {
	switch (msg) {
	case WM_CREATE: {
		hStatic1 = CreateWindow(L"Static", L"a:", WS_VISIBLE | WS_CHILD, 6, 5, 12, 20, hWnd, NULL, NULL, NULL);
		hStatic2 = CreateWindow(L"Static", L"c:", WS_VISIBLE | WS_CHILD, 7, 30, 10, 20, hWnd, NULL, NULL, NULL);
		hStatic3 = CreateWindow(L"Static", L"d:", WS_VISIBLE | WS_CHILD, 6, 55, 11, 20, hWnd, NULL, NULL, NULL);
		hStatic4 = CreateWindow(L"Static", L"S:", WS_VISIBLE | WS_CHILD, 5, 80, 12, 20, hWnd, NULL, NULL, NULL);
		hEdit1 = CreateWindow(L"Edit", NULL, WS_VISIBLE | WS_CHILD | ES_AUTOHSCROLL | WS_BORDER, 22, 5, 250, 20, hWnd, NULL, NULL, NULL);
		hEdit2 = CreateWindow(L"Edit", NULL, WS_VISIBLE | WS_CHILD | ES_AUTOHSCROLL | WS_BORDER, 22, 30, 250, 20, hWnd, NULL, NULL, NULL);
		hEdit3 = CreateWindow(L"Edit", NULL, WS_VISIBLE | WS_CHILD | ES_AUTOHSCROLL | WS_BORDER, 22, 55, 250, 20, hWnd, NULL, NULL, NULL);
		hEdit4 = CreateWindow(L"Edit", L"3 * ((a + c + d) ^ 2)", WS_VISIBLE | WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_DISABLED, 22, 80, 250, 20, hWnd, NULL, NULL, NULL);
		hButton1 = CreateWindow(L"Button", L"��������� �������", WS_VISIBLE | WS_CHILD | WS_BORDER, 5, 105, 267, 20, hWnd, (HMENU)ID_BUTTON1, NULL, NULL);
	}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_COMMAND: {
		switch (LOWORD(wp)) {
		case ID_BUTTON1: {
			try {
				int l = GetWindowTextLength(hEdit1);
				char* t = new char[l + 1];
				GetWindowTextA(hEdit1, t, l + 1);
				double a = stod(t);
				delete[] t;
				l = GetWindowTextLength(hEdit2);
				t = new char[l + 1];
				GetWindowTextA(hEdit2, t, l + 1);
				double c = stod(t);
				delete[] t;
				l = GetWindowTextLength(hEdit3);
				t = new char[l + 1];
				GetWindowTextA(hEdit3, t, l + 1);
				double d = stod(t);
				delete[] t;
				string r = to_string(3 * (a + c + d) * (a + c + d));
				const char* rc = new char[r.length() + 1];
				rc = r.c_str();
				SetWindowTextA(hEdit4, rc);
				delete[] rc;
			}
			catch (invalid_argument) {
				MessageBox(hWnd, L"������� ������������ ������", L"������", NULL);
			}
			catch (out_of_range) {
				MessageBox(hWnd, L"������� ������������ ������", L"������", NULL);
			}
		}
			break;
		default:
			return DefWindowProcW(hWnd, msg, wp, lp);
		}
	}
	default:
		return DefWindowProcW(hWnd, msg, wp, lp);
	}
}
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR args, int ncmdshow) {
	WNDCLASS wndclass = { 0 };
	wndclass.hbrBackground = (HBRUSH)COLOR_WINDOW;
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hIcon = LoadIcon(NULL, IDI_SHIELD);
	wndclass.hInstance = hInst;
	wndclass.lpszClassName = L"LRWindowClass";
	wndclass.lpfnWndProc = WindowProcedure;
	if (!RegisterClassW(&wndclass))
		return -1;
	hMain = CreateWindow(L"LRWindowClass", L"�� �15-16. �12", WS_SYSMENU | WS_MINIMIZEBOX | WS_VISIBLE, 0, 0, 283, 159, NULL, NULL, NULL, NULL);
	MSG msg = { 0 };
	while (GetMessage(&msg, NULL, NULL, NULL)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return 0;
}