﻿#include <iostream>
#include <string>
#include <fstream>
#include <windows.h>
using namespace std;
using namespace string_literals;


class BookList {

public:
    int i = 0, j = 0; //Индекс для удаления
    string tit, auth, books_in_stock, all_books; //Название полей файла

    void addToList() {
        string title, allBooks, booksInStock, zap = ";", per = "\n", author;
        fstream FILE;
        FILE.open("data.csv");

        while (FILE.good()) {
            getline(FILE, auth, ';');
            getline(FILE, tit, ';');
            getline(FILE, all_books, ';');
            getline(FILE, books_in_stock, '\n');
        }
        FILE.close();
        cout << "Автор книги\n";
        cin >> author;
        cout << "Название книги без пробелов 'ВотТак':\n";
        cin >> title;
        cout << "Всего книг\n";
        cin >> allBooks;
        cout << "Книг на руках\n";
        cin >> booksInStock;

        if (author != title) {
            FILE.open("data.csv", std::ios::app);
            FILE << per << author << zap << title << zap << allBooks << zap << booksInStock << zap;
            FILE.close();
        }
        else
            cout << "Данные неверны\n";
        cout << "\n";
    };
    void findByAuthor() {
        fstream FILE;
        int n = 0;
        string author;

        cout << "\n";
        cout << "Введите автора для поиска:";
        cin >> author;
        cout << "Книги автора:\n";
        FILE.open("data.csv");
        while (FILE.good()) {
            string b;
            string prifix;

            getline(FILE, auth, ';');
            getline(FILE, tit, ';');
            getline(FILE, all_books, ';');
            getline(FILE, books_in_stock, '\n');

            for (char i : auth) {
                prifix.push_back(i);
                if (i != '\n')
                    b.push_back(i);
            }


            if (b == author) {
                cout << "Название книги: " << tit << " " << "Всего книг: " << all_books << " " << "Книг на руках: " << books_in_stock << " " << "\n\n";
                n++;
            }
        }
        if (n == 0)
            cout << "Таких книг нет\n";
        cout << "\n";
    }
    void showAll() {
        fstream FILE;
        FILE.open("data.csv");
        while (FILE.good()) {

            getline(FILE, auth, ';');
            getline(FILE, tit, ';');
            getline(FILE, all_books, ';');
            getline(FILE, books_in_stock, '\n');

            if (!auth.empty() && !tit.empty() && !all_books.empty() && !books_in_stock.empty())
                cout << "Автор: " << auth << " Название книги: " << tit << " Всего книг: " << all_books << " Книг на руках: " << books_in_stock << "\n\n";
            else { cout << "Конец\n\n"; };
        }
        FILE.close();
        cout << "\n";
    }
    int deleteFromList() {
        fstream FILE;
        fstream COPY;
        string  zap = ";", per = "\n";
        int i = 1, currentLine;
        bool  estNujnayaStroka = false, firstLine = true;

        FILE.open("data.csv");
        while (FILE.good()) {
            getline(FILE, auth, ';');
            getline(FILE, tit, ';');
            getline(FILE, all_books, ';');
            getline(FILE, books_in_stock, '\n');

            if (!auth.empty() && !tit.empty() && !all_books.empty() && !books_in_stock.empty())
                cout << i << " " << "Автор: " << auth << " Название книги: " << tit << " Всего книг: " << all_books << " Книг на руках: " << books_in_stock << "\n\n";
            else { cout << "Конец\n\n"; };
            i++;
        }
        FILE.close();
        FILE.open("data.csv");
        cout << "Введите номер строки, которую надо удалить\n";
        cin >> currentLine;
        i = 1;
        COPY.open("copy.csv", std::ios::app);
        while (FILE.good()) {

            getline(FILE, auth, ';');
            getline(FILE, tit, ';');
            getline(FILE, all_books, ';');
            getline(FILE, books_in_stock, '\n');

            if (currentLine == i) {
                cout << "Автор: " << auth << " Название книги: " << tit << " Всего книг: " << all_books << " Книг на руках: " << books_in_stock << "\n\n";
                estNujnayaStroka = true;
            }
            else {
                if (firstLine) {
                    COPY << auth << zap << tit << zap << all_books << zap << books_in_stock;
                    firstLine = false;
                }
                else {
                    COPY << per << auth << zap << tit << zap << all_books << zap << books_in_stock;
                }
            }
            i++;
        }
        FILE.close();
        COPY.close();
        if (estNujnayaStroka) {
            rename("data.csv", "copy1.csv");
            rename("copy.csv", "data.csv");
            remove("copy1.csv");
        }
        else {
            cout << "Строки с таким номером нет\n";
            remove("copy.csv");
            return 0;
        }
        cout << "\n";
        return 0;
    }
};


int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);
    setlocale(LC_ALL, "Russian");
    BookList bookList;
    bool m = true;
    int deistv;
    while (m)
    {
        cout << "Выберите действие:\n";
        cout << "1. Добавить книгу\n";
        cout << "2. Искать книгу по автору\n";
        cout << "3. Посмотреть все книги\n";
        cout << "4. Удалить книгу из списка\n";
        cout << "5. Выйти\n";
        cout << "\n";
        cin >> deistv;
        cout << "\n";

        if (deistv == 1) {
            bookList.addToList();
        }
        else if (deistv == 2) {
            bookList.findByAuthor();
        }
        else if (deistv == 3) {
            bookList.showAll();
        }
        else if (deistv == 4) {
            bookList.deleteFromList();
        }
        else if (deistv == 5) {
            m = false;
        }
        else {
            cout << "Нет такого действия\n";
        }
    }
}
