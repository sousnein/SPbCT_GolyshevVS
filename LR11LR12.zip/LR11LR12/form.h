#pragma once
#include "complex.h"
#include "vector_template.h"

namespace LR11LR12 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� form
	/// </summary>
	public ref class form : public System::Windows::Forms::Form
	{
	public:
		form(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~form()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	protected:
	private: System::Windows::Forms::TextBox^ textBox1;

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(12, 406);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(600, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"���������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &form::button1_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(13, 13);
			this->textBox1->Multiline = true;
			this->textBox1->Name = L"textBox1";
			this->textBox1->ReadOnly = true;
			this->textBox1->Size = System::Drawing::Size(599, 387);
			this->textBox1->TabIndex = 1;
			// 
			// form
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(624, 441);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->button1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->Name = L"form";
			this->ShowIcon = false;
			this->Text = L"�� �11-12";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		bool Counted = false;
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		if (Counted == false) {
			Counted = true;
			Vector<int> I1(111), I2(100), I3(10);
			I1.Insert(1), I2.Insert(1), I3.Insert(1);
			I1[1] = 222, I2[1] = 200, I3[1] = 20;
			textBox1->Text = "I1: " + I1.Print() + "\r\nI2: " + I2.Print() + "\r\nI3: " + I3.Print() + "\r\n\r\n";
			I2 = I1 - I3, I3 = I2, I1 = I1 - 1000;
			textBox1->Text += "I1: " + I1.Print() + "\r\nI2: " + I2.Print() + "\r\nI3: " + I3.Print() + "\r\n\r\n";
			Vector<double> D1(111.1), D2(100.1), D3(10.1);
			D1.Insert(1), D2.Insert(1), D3.Insert(1);
			D1[1] = 222.2, D2[1] = 200.2, D3[1] = 20.2;
			textBox1->Text += "D1: " + D1.Print() + "\r\nD2: " + D2.Print() + "\r\nD3: " + D3.Print() + "\r\n\r\n";
			D2 = D1 - D3, D3 = D2, D1 = D1 - 1000.5;
			textBox1->Text += "D1: " + D1.Print() + "\r\nD2: " + D2.Print() + "\r\nD3: " + D3.Print() + "\r\n\r\n";
			Vector<Complex> C1, C2, C3;
			C1[0].Input(111.1, 555.5), C2[0].Input(100.1, 500.5), C3[0].Input(10.1, 50.5);
			C1.Insert(1), C2.Insert(1), C3.Insert(1);
			C1[1].Input(222.2, 666.6), C2[1].Input(200.2, 600.6), C3[1].Input(20.2, 60.6);
			textBox1->Text += "C1: " + C1.Print() + "\r\nC2: " + C2.Print() + "\r\nC3: " + C3.Print() + "\r\n\r\n";
			const Complex C(1000.5, 7777.7);
			C2 = C1 - C3, C3 = C2, C1 = C1 - C;
			textBox1->Text += "C1: " + C1.Print() + "\r\nC2: " + C2.Print() + "\r\nC3: " + C3.Print();
		}
	}
	};
}